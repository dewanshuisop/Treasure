# Dewanshuisop's Treasure

Your All-in-One AI Content Creation Platform for YouTube Creators.

## Getting Started Locally

Once you've downloaded the source code or cloned the repository, follow these steps to run the project on your machine:

1.  **Install Dependencies:**
    ```bash
    npm install
    ```

2.  **Environment Variables:**
    Create a `.env` file in the root directory and add your Firebase and Genkit API keys.

3.  **Run the Development Server:**
    ```bash
    npm run dev
    ```

4.  **Open the App:**
    Open [http://localhost:9002](http://localhost:9002) (or the port specified in your terminal) in your browser.

## Features

- **Script Sculptor:** Generate high-converting YouTube scripts.
- **Retention Optimizer:** Polish your drafts for maximum audience retention.
- **Viral Niche Explorer:** Discover high-potential video ideas.
- **Thumbnail Visualizer:** Create AI-generated thumbnails.
- **Voice Synthesis Engine:** Professional AI narration for your scripts.

## Tech Stack

- **Framework:** Next.js 15 (App Router)
- **UI:** React, ShadCN UI, Tailwind CSS
- **AI:** Genkit, Google Gemini Models
- **Backend:** Firebase (Firestore, Auth)
