# **App Name**: Dewanshu's Treasure

## Core Features:

- Script Sculptor Tool: Uses AI tools to generate multi-part YouTube scripts including hooks, intros, and CTAs tailored to audience and duration.
- Retention Optimizer Tool: An intelligent tool to analyze and improve existing scripts for higher audience engagement and retention.
- Viral Niche Explorer Tool: Generates 50 content ideas with metrics like difficulty score and estimated views based on niche data.
- Thumbnail Visualizer Tool: Creates high-quality 16:9 or 9:16 thumbnail concepts using text-to-image generative models.
- Voice Synthesis Engine Tool: Transforms text scripts into high-fidelity AI-generated audio with customizable styles like 'Storytelling' or 'Energetic'.
- The Vault Dashboard: Centralized storage for all scripts, thumbnail prompts, and audio files, saved to the Firestore database for easy retrieval.
- Creator Export: Batch export projects including scripts as TXT, thumbnails as PNG, and audio as MP3 into a single ZIP archive.

## Style Guidelines:

- Primary color: Electric Amethyst (#BC61F5), a vibrant purple for creative energy and professional SaaS aesthetics.
- Background color: Deep Obsidian Space (#120E15), providing a high-contrast foundation for neon UI accents.
- Accent color: Cyber Cyan (#42D0FA), an analogous bright hue used for CTAs and highlights.
- Font pairing: 'Space Grotesk' for high-tech, futuristic headlines and 'Inter' for clear, legible body content across the dashboard.
- Line-art style icons with soft outer glows (bloom effect) in primary and accent colors to represent tools like audio, imagery, and text.
- Modern SaaS dashboard layout featuring a collapsible side sidebar, modular feature cards, and wide gutters for a spacious, professional feel.
- Micro-interactions featuring CSS-based neon glows and subtle scaling effects on hover for an immersive, tactile UI experience.