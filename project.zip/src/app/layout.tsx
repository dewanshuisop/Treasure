import type {Metadata} from 'next';
import './globals.css';
import { Toaster } from "@/components/ui/toaster"
import { FloatingShapes } from "@/components/floating-shapes"

export const metadata: Metadata = {
  title: "Dewanshuisop's Treasure | AI Creator Platform",
  description: 'Your All-in-One AI Content Creation Platform for YouTube Creators.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased bg-background text-foreground min-h-screen relative overflow-x-hidden">
        <FloatingShapes />
        <div id="main-content-wrapper">
          {children}
        </div>
        <Toaster />
      </body>
    </html>
  );
}