import Link from 'next/link';
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { FileText, Wand2, Lightbulb, ArrowRight, Zap, Shield, Sparkles } from "lucide-react";

function DiscordIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
      <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515a.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0a12.64 12.64 0 0 0-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057a19.9 19.9 0 0 0 5.993 3.03a.078.078 0 0 0 .084-.028a14.09 14.09 0 0 0 1.226-1.994a.076.076 0 0 0-.041-.106a13.107 13.107 0 0 1-1.872-.892a.077.077 0 0 1-.008-.128a10.2 10.2 0 0 0 .372-.292a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127a12.299 12.299 0 0 1-1.873.892a.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028a19.839 19.839 0 0 0 6.002-3.03a.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.956-2.419 2.157-2.419c1.21 0 2.176 1.086 2.157 2.419c0 1.334-.947 2.419-2.157 2.419zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.955-2.419 2.157-2.419c1.21 0 2.176 1.086 2.157 2.419c0 1.334-.946 2.419-2.157 2.419z" />
    </svg>
  );
}

export default function Home() {
  const features = [
    {
      title: "Script Sculptor",
      description: "Generate complete, high-converting YouTube scripts from simple prompts.",
      icon: <FileText className="w-8 h-8 text-primary" />,
      href: "/dashboard/script-maker"
    },
    {
      title: "Retention Optimizer",
      description: "Analyze and rewrite scripts to keep your viewers hooked until the end.",
      icon: <Wand2 className="w-8 h-8 text-secondary" />,
      href: "/dashboard/script-improver"
    },
    {
      title: "Viral Niche Explorer",
      description: "Discover high-potential video ideas with viral scores and view estimates.",
      icon: <Lightbulb className="w-8 h-8 text-yellow-400" />,
      href: "/dashboard/video-ideas"
    }
  ];

  return (
    <div className="flex flex-col min-h-screen">
      <header className="fixed top-0 w-full z-50 glass-morphism border-b px-6 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="w-6 h-6 text-primary animate-pulse" />
          <span className="font-headline font-bold text-xl bg-clip-text text-transparent bg-gradient-to-r from-primary to-accent">
            Dewanshuisop's Treasure
          </span>
        </div>
        <nav className="hidden md:flex items-center gap-4 text-sm font-medium">
          <Link href="#features" className="hover:text-primary transition-colors mr-4">Features</Link>
          <Button 
            variant="ghost" 
            size="sm" 
            className="flex items-center gap-2 text-muted-foreground hover:text-[#5865F2] transition-colors"
            asChild
          >
            <Link href="https://discordapp.com/users/831023230206345277" target="_blank">
              <DiscordIcon className="w-5 h-5" />
              <span className="text-xs font-bold uppercase tracking-widest">get feedback here</span>
            </Link>
          </Button>
          <Separator orientation="vertical" className="h-6 mx-2" />
          <Button asChild variant="outline" size="sm" className="border-primary/50 text-primary hover:bg-primary/10">
            <Link href="/login">Sign In</Link>
          </Button>
          <Button asChild size="sm" className="bg-primary hover:bg-primary/90 neon-glow-primary">
            <Link href="/register">Get Started</Link>
          </Button>
        </nav>
      </header>

      <main className="flex-1 pt-16">
        <section className="relative py-24 md:py-32 px-6 overflow-hidden">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[600px] bg-primary/20 blur-[120px] rounded-full -z-10" />
          
          <div className="max-w-5xl mx-auto text-center space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium">
              <Zap className="w-4 h-4" />
              <span>Next-Gen Content Creation</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold leading-[1.1]">
              Unlock Your <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary via-accent to-primary animate-gradient">Creative Treasure</span>
            </h1>
            
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Your All-in-One AI Content Creation Platform. Generate scripts, optimize retention, and explore niches in seconds.
            </p>
            
            <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
              <Button size="lg" className="h-14 px-8 text-lg font-headline bg-primary hover:bg-primary/90 neon-glow-primary" asChild>
                <Link href="/dashboard">Get Started Free <ArrowRight className="ml-2 w-5 h-5" /></Link>
              </Button>
              <Button size="lg" variant="outline" className="h-14 px-8 text-lg font-headline border-accent/30 hover:bg-accent/10" asChild>
                <Link href="#features">Explore Features</Link>
              </Button>
            </div>
          </div>
        </section>

        <section id="features" className="py-24 px-6 bg-card/30">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16 space-y-4">
              <h2 className="text-3xl md:text-5xl font-bold">The Creator Toolkit</h2>
              <p className="text-muted-foreground max-xl mx-auto">Everything you need to dominate YouTube and social media using the power of generative AI.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {features.map((feature, idx) => (
                <Link key={idx} href={feature.href} className="group">
                  <Card className="h-full bg-card hover:bg-muted/50 transition-all border-white/5 hover:border-primary/50 cyber-border group-hover:-translate-y-1">
                    <CardHeader>
                      <div className="mb-4 p-3 rounded-xl bg-white/5 w-fit group-hover:scale-110 transition-transform">
                        {feature.icon}
                      </div>
                      <CardTitle className="text-xl group-hover:text-primary transition-colors">{feature.title}</CardTitle>
                      <CardDescription className="text-base pt-2">{feature.description}</CardDescription>
                    </CardHeader>
                  </Card>
                </Link>
              ))}
              <Card className="h-full bg-gradient-to-br from-primary/20 to-accent/20 border-primary/30 flex flex-col items-center justify-center p-8 text-center space-y-4">
                <Shield className="w-12 h-12 text-primary" />
                <h3 className="text-2xl font-bold">The Vault</h3>
                <p className="text-sm">Securely store and manage all your AI-generated assets in one place.</p>
                <Button variant="secondary" className="w-full" asChild>
                  <Link href="/dashboard/vault">Visit The Vault</Link>
                </Button>
              </Card>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t py-12 px-6">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            <span className="font-headline font-bold text-lg">Dewanshuisop's Treasure</span>
          </div>
          <div className="flex gap-8 text-sm text-muted-foreground">
            <Link href="https://discordapp.com/users/831023230206345277" target="_blank" className="hover:text-[#5865F2] flex items-center gap-1 transition-colors">
              <DiscordIcon className="w-4 h-4" /> Discord Feedback
            </Link>
            <Link href="#" className="hover:text-primary transition-colors">Terms</Link>
            <Link href="#" className="hover:text-primary transition-colors">Contact</Link>
          </div>
          <p className="text-sm text-muted-foreground">© 2024 Dewanshuisop's Treasure.</p>
        </div>
      </footer>
    </div>
  );
}

const Separator = ({ className, orientation = 'horizontal' }: { className?: string; orientation?: 'horizontal' | 'vertical' }) => (
  <div className={`bg-border ${orientation === 'horizontal' ? 'h-[1px] w-full' : 'h-full w-[1px]'} ${className}`} />
);
