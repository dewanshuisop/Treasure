"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Search, 
  FileText, 
  Lightbulb, 
  MoreVertical, 
  Trash2, 
  ExternalLink, 
  Copy,
  Archive,
  Filter,
  ArrowUpDown
} from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";

type SavedItem = {
  id: string;
  title: string;
  type: 'Script' | 'Idea';
  date: string;
  preview: string;
  tags: string[];
};

const MOCK_ITEMS: SavedItem[] = [
  {
    id: "1",
    title: "10 AI Tools for 2024",
    type: "Script",
    date: "2024-03-20",
    preview: "In this video, we're diving deep into the most revolutionary AI tools...",
    tags: ["Tech", "Tutorial"]
  },
  {
    id: "2",
    title: "Sustainable Living for Beginners",
    type: "Idea",
    date: "2024-03-18",
    preview: "Hook: What if I told you that zero-waste living saves you $200 a month?",
    tags: ["Lifestyle", "Eco"]
  },
  {
    id: "3",
    title: "The Future of Gaming Consoles",
    type: "Script",
    date: "2024-03-15",
    preview: "Are physical consoles dying? Today we examine the shift to cloud gaming.",
    tags: ["Gaming", "Analysis"]
  }
];

export default function VaultPage() {
  const { toast } = useToast();
  const [items] = useState<SavedItem[]>(MOCK_ITEMS);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<'All' | 'Script' | 'Idea'>('All');

  const filteredItems = items.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(search.toLowerCase());
    const matchesFilter = filter === 'All' || item.type === filter;
    return matchesSearch && matchesFilter;
  });

  const handleCopy = (content: string) => {
    navigator.clipboard.writeText(content);
    toast({ title: "Copied!", description: "Content copied to clipboard." });
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Archive className="w-8 h-8 text-primary" /> The Vault
          </h1>
          <p className="text-muted-foreground mt-1">Manage and access your collection of AI-generated assets.</p>
        </div>
      </div>

      <Card className="bg-card/50 border-white/5">
        <CardContent className="p-4 md:p-6">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="relative w-full md:w-96">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Search treasures..." 
                className="pl-10 bg-muted/20 border-white/10"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-2 md:pb-0">
              <Button 
                variant={filter === 'All' ? 'default' : 'outline'} 
                size="sm"
                onClick={() => setFilter('All')}
                className="h-8 border-white/10"
              >
                All
              </Button>
              <Button 
                variant={filter === 'Script' ? 'default' : 'outline'} 
                size="sm"
                onClick={() => setFilter('Script')}
                className="h-8 border-white/10"
              >
                <FileText className="w-3 h-3 mr-1" /> Scripts
              </Button>
              <Button 
                variant={filter === 'Idea' ? 'default' : 'outline'} 
                size="sm"
                onClick={() => setFilter('Idea')}
                className="h-8 border-white/10"
              >
                <Lightbulb className="w-3 h-3 mr-1" /> Ideas
              </Button>
              <Button variant="ghost" size="sm" className="h-8">
                <ArrowUpDown className="w-3 h-3 mr-1" /> Date
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {filteredItems.length === 0 ? (
        <Card className="border-dashed border-white/10 bg-transparent py-20">
          <CardContent className="flex flex-col items-center justify-center text-center space-y-4">
            <Archive className="w-12 h-12 text-muted-foreground/30" />
            <div className="space-y-1">
              <p className="font-medium text-muted-foreground">No treasures found</p>
              <p className="text-sm text-muted-foreground/50">Try adjusting your search or filters.</p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <Card key={item.id} className="group hover:bg-muted/20 transition-all border-white/5 hover:border-primary/30 flex flex-col h-full">
              <CardHeader className="pb-3 flex flex-row items-start justify-between space-y-0">
                <div className="space-y-1 pr-4">
                  <div className="flex items-center gap-2">
                    {item.type === 'Script' ? (
                      <FileText className="w-4 h-4 text-primary" />
                    ) : (
                      <Lightbulb className="w-4 h-4 text-yellow-400" />
                    )}
                    <span className="text-[10px] uppercase font-bold tracking-widest text-muted-foreground">
                      {item.type}
                    </span>
                  </div>
                  <CardTitle className="text-lg leading-tight line-clamp-2">{item.title}</CardTitle>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground">
                      <MoreVertical className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="bg-card border-white/10">
                    <DropdownMenuItem className="cursor-pointer">
                      <ExternalLink className="w-4 h-4 mr-2" /> Open
                    </DropdownMenuItem>
                    <DropdownMenuItem className="cursor-pointer" onClick={() => handleCopy(item.preview)}>
                      <Copy className="w-4 h-4 mr-2" /> Copy Content
                    </DropdownMenuItem>
                    <DropdownMenuItem className="cursor-pointer text-destructive focus:text-destructive">
                      <Trash2 className="w-4 h-4 mr-2" /> Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </CardHeader>
              <CardContent className="flex-1 space-y-4">
                <p className="text-sm text-muted-foreground line-clamp-3 italic">
                  "{item.preview}"
                </p>
                <div className="flex flex-wrap gap-2">
                  {item.tags.map(tag => (
                    <Badge key={tag} variant="outline" className="bg-white/5 border-white/10 text-[10px]">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </CardContent>
              <div className="p-4 border-t border-white/5 flex items-center justify-between text-xs text-muted-foreground bg-muted/10 mt-auto">
                <span className="flex items-center gap-1">
                  Saved on {new Date(item.date).toLocaleDateString()}
                </span>
                <Button variant="link" size="sm" className="h-auto p-0 text-primary">
                  View Full <ExternalLink className="w-3 h-3 ml-1" />
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
