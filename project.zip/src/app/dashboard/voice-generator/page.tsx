"use client";

import { useState } from "react";
import { generateVoiceoverAudio, type GenerateVoiceoverAudioOutput } from "@/ai/flows/generate-voiceover-audio-flow";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Loader2, Mic2, Download, Save, Play, Pause, Volume2, Sparkles } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function VoiceGeneratorPage() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<GenerateVoiceoverAudioOutput | null>(null);
  const [audioRef, setAudioRef] = useState<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [formData, setFormData] = useState({
    scriptText: "",
    language: "en-US",
    voiceGender: "FEMALE" as "MALE" | "FEMALE" | "NEUTRAL",
    voiceStyle: "Storytelling" as "Storytelling" | "Documentary" | "Energetic" | "Professional" | "Motivational"
  });

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.scriptText) return;
    if (formData.scriptText.length > 1000) {
       toast({ title: "Limit Exceeded", description: "Keep script under 1000 chars for better results.", variant: "destructive" });
       return;
    }
    
    setLoading(true);
    setResult(null);
    try {
      const output = await generateVoiceoverAudio(formData);
      setResult(output);
      toast({ title: "Voice Found!", description: "Audio synthesized successfully." });
    } catch (error) {
      toast({ title: "Error", description: "Failed to synthesize voice. Please try again.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const togglePlayback = () => {
    if (!audioRef) return;
    if (isPlaying) {
      audioRef.pause();
    } else {
      audioRef.play();
    }
    setIsPlaying(!isPlaying);
  };

  const downloadAudio = () => {
    if (!result) return;
    const link = document.createElement('a');
    link.href = result.audioDataUri;
    link.download = `voiceover-${Date.now()}.wav`;
    link.click();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="space-y-1">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Mic2 className="w-8 h-8 text-red-400" /> Voice Synthesis Engine
        </h1>
        <p className="text-muted-foreground">Bring your scripts to life with professional AI narration.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <Card className="md:col-span-1 bg-card/50 border-white/5 h-fit">
          <CardHeader>
            <CardTitle>Narrator Settings</CardTitle>
            <CardDescription>Customize the vocal profile</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleGenerate} className="space-y-6">
               <div className="space-y-2">
                <Label htmlFor="gender">Voice Type</Label>
                <Select value={formData.voiceGender} onValueChange={v => setFormData({...formData, voiceGender: v as any})}>
                  <SelectTrigger className="bg-muted/50 border-white/10">
                    <SelectValue placeholder="Gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="FEMALE">Female</SelectItem>
                    <SelectItem value="MALE">Male</SelectItem>
                    <SelectItem value="NEUTRAL">Neutral</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="style">Narrative Style</Label>
                <Select value={formData.voiceStyle} onValueChange={v => setFormData({...formData, voiceStyle: v as any})}>
                  <SelectTrigger className="bg-muted/50 border-white/10">
                    <SelectValue placeholder="Style" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Storytelling">Storytelling</SelectItem>
                    <SelectItem value="Documentary">Documentary</SelectItem>
                    <SelectItem value="Energetic">Energetic</SelectItem>
                    <SelectItem value="Professional">Professional</SelectItem>
                    <SelectItem value="Motivational">Motivational</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button type="submit" disabled={loading} className="w-full bg-red-500 hover:bg-red-600 neon-glow-accent text-white border-none">
                {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Sparkles className="w-4 h-4 mr-2" />}
                Synthesize Audio
              </Button>
            </form>
          </CardContent>
        </Card>

        <div className="md:col-span-2 space-y-6">
          <Card className="bg-card/50 border-white/5">
            <CardHeader>
              <CardTitle>Script Input</CardTitle>
              <CardDescription>Enter the text you want to convert to speech</CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea 
                placeholder="Paste your hook or introduction here..." 
                className="min-h-[250px] bg-muted/20 border-white/10 focus-visible:ring-red-400"
                value={formData.scriptText}
                onChange={e => setFormData({...formData, scriptText: e.target.value})}
              />
              <div className="flex justify-between mt-2 text-xs text-muted-foreground">
                <span>Recommended: 100-500 chars per segment</span>
                <span>{formData.scriptText.length} / 1000</span>
              </div>
            </CardContent>
          </Card>

          {loading && (
             <Card className="bg-red-500/5 border-red-500/20 p-8">
              <div className="flex flex-col items-center gap-4">
                <div className="flex gap-1 items-center h-8">
                  {[...Array(8)].map((_, i) => (
                    <div key={i} className="w-1.5 bg-red-400 rounded-full animate-bounce" style={{ height: `${Math.random() * 100}%`, animationDelay: `${i * 0.1}s` }} />
                  ))}
                </div>
                <p className="text-sm font-medium text-red-400">Capturing vocal nuances...</p>
              </div>
             </Card>
          )}

          {result && (
            <Card className="bg-gradient-to-r from-red-500/10 to-primary/5 border-red-500/20 overflow-hidden animate-in fade-in zoom-in-95">
              <div className="p-8 space-y-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <Button onClick={togglePlayback} size="icon" className="w-16 h-16 rounded-full bg-red-500 hover:bg-red-600 neon-glow-primary">
                      {isPlaying ? <Pause className="w-8 h-8 fill-white" /> : <Play className="w-8 h-8 ml-1 fill-white" />}
                    </Button>
                    <div>
                      <p className="font-headline font-bold text-xl uppercase tracking-widest">{formData.voiceStyle}</p>
                      <p className="text-muted-foreground text-sm flex items-center gap-1">
                        <Volume2 className="w-4 h-4" /> HQ Audio Synthesis Ready
                      </p>
                    </div>
                  </div>
                  <div className="hidden sm:flex flex-col gap-2">
                    <Button variant="outline" size="sm" onClick={downloadAudio} className="border-red-500/20 hover:bg-red-500/10">
                      <Download className="w-4 h-4 mr-2" /> Download MP3
                    </Button>
                    <Button variant="outline" size="sm" className="border-primary/20 hover:bg-primary/10">
                      <Save className="w-4 h-4 mr-2" /> Save to Vault
                    </Button>
                  </div>
                </div>
                
                <audio 
                  ref={el => setAudioRef(el)}
                  src={result.audioDataUri} 
                  onEnded={() => setIsPlaying(false)}
                  className="hidden"
                />

                <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
                  <div className="h-full bg-red-400 animate-pulse" style={{ width: isPlaying ? '100%' : '0%', transition: 'width 0.1s linear' }} />
                </div>
                
                <div className="sm:hidden flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1" onClick={downloadAudio}>
                      <Download className="w-4 h-4 mr-2" /> Download
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1">
                      <Save className="w-4 h-4 mr-2" /> Save
                    </Button>
                </div>
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
