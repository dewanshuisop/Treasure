"use client";

import { useState } from "react";
import { improveExistingScript, type ImproveExistingScriptOutput } from "@/ai/flows/improve-existing-script-flow";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Loader2, Sparkles, Wand2, Copy, CheckCircle2, ListChecks } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function ScriptImproverPage() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ImproveExistingScriptOutput | null>(null);
  const [formData, setFormData] = useState({
    existingScript: "",
    improvementOption: "More Engaging" as "More Engaging" | "More Emotional" | "More Viral" | "More Professional" | "More Educational"
  });

  const handleImprove = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.existingScript) return;

    setLoading(true);
    try {
      const output = await improveExistingScript(formData);
      setResult(output);
      toast({ title: "Polish applied!", description: "Your script has been optimized for better retention." });
    } catch (error) {
      toast({ title: "Error", description: "Optimization failed. The AI is feeling a bit stuck.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    if (!result) return;
    navigator.clipboard.writeText(result.improvedScript);
    toast({ title: "Copied!", description: "Improved script copied to clipboard." });
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="space-y-1">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Wand2 className="w-8 h-8 text-secondary" /> Retention Optimizer
        </h1>
        <p className="text-muted-foreground">Inject viral energy and retention-boosting hooks into your drafts.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-5 space-y-6">
          <Card className="bg-card/50 border-white/5">
            <CardHeader>
              <CardTitle>Optimization Strategy</CardTitle>
              <CardDescription>Choose how you want to improve your content</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleImprove} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="strategy">Improvement Goal</Label>
                  <Select 
                    value={formData.improvementOption} 
                    onValueChange={v => setFormData({...formData, improvementOption: v as any})}
                  >
                    <SelectTrigger className="bg-muted/50 border-white/10">
                      <SelectValue placeholder="Select strategy" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="More Engaging">More Engaging (Retention Focus)</SelectItem>
                      <SelectItem value="More Emotional">More Emotional (Connection Focus)</SelectItem>
                      <SelectItem value="More Viral">More Viral (Hype Focus)</SelectItem>
                      <SelectItem value="More Professional">More Professional (Authority Focus)</SelectItem>
                      <SelectItem value="More Educational">More Educational (Clarity Focus)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="script">Draft Script</Label>
                  <Textarea 
                    id="script"
                    placeholder="Paste your rough draft here..." 
                    className="min-h-[300px] bg-muted/20 border-white/10 focus-visible:ring-secondary"
                    value={formData.existingScript}
                    onChange={e => setFormData({...formData, existingScript: e.target.value})}
                  />
                  <p className="text-right text-[10px] text-muted-foreground">{formData.existingScript.length} characters</p>
                </div>
                <Button type="submit" disabled={loading} className="w-full bg-secondary hover:bg-secondary/90 text-secondary-foreground font-bold neon-glow-accent">
                  {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Sparkles className="w-4 h-4 mr-2" />}
                  Optimize Retention
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-7 space-y-6">
          {!result && !loading && (
            <Card className="border-dashed border-white/10 bg-transparent h-full min-h-[500px] flex items-center justify-center">
              <div className="text-center space-y-4 max-w-xs opacity-40">
                <Wand2 className="w-16 h-16 mx-auto mb-2" />
                <p className="text-sm italic">Paste your script and select a strategy to see the AI magic.</p>
              </div>
            </Card>
          )}

          {loading && (
            <Card className="bg-card/50 border-white/5 min-h-[500px] flex flex-col items-center justify-center p-12 text-center">
              <div className="relative mb-8">
                <div className="w-24 h-24 rounded-full border-t-2 border-secondary animate-spin" />
                <Sparkles className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 text-secondary animate-pulse" />
              </div>
              <h3 className="text-xl font-bold mb-2 text-secondary animate-pulse">dewanshuisop is using his brain...</h3>
              <p className="text-muted-foreground text-sm">Our AI is re-sculpting your script for maximum audience hook rate.</p>
            </Card>
          )}

          {result && (
            <div className="space-y-6 animate-in fade-in duration-500">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-bold flex items-center gap-2">
                   <CheckCircle2 className="w-5 h-5 text-green-400" /> Improved Version
                </h3>
                <Button variant="outline" size="sm" onClick={copyToClipboard}>
                  <Copy className="w-4 h-4 mr-2" /> Copy Script
                </Button>
              </div>

              <Card className="bg-card border-white/5">
                <CardContent className="p-6">
                   <div className="whitespace-pre-wrap leading-relaxed text-sm text-foreground/90">
                    {result.improvedScript}
                   </div>
                </CardContent>
              </Card>

              <Card className="bg-muted/30 border-secondary/20 border">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-bold flex items-center gap-2 uppercase tracking-widest text-secondary">
                    <ListChecks className="w-4 h-4" /> AI Improvement Log
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {result.suggestions.map((suggestion, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs">
                      <span className="text-secondary mt-0.5">•</span>
                      <p className="text-muted-foreground">{suggestion}</p>
                    </div>
                  ))}
                </CardContent>
              </Card>
              
              <div className="flex justify-center">
                <Button variant="secondary" className="bg-secondary/10 hover:bg-secondary/20 border-secondary/20 text-secondary border">
                   Save Improved Version to Vault
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
