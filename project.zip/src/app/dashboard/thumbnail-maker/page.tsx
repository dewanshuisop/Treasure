"use client";

import { useState } from "react";
import { generateThumbnailImage, type GenerateThumbnailImageOutput } from "@/ai/flows/generate-thumbnail-image-flow";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Loader2, Sparkles, Image as ImageIcon, Download, Save, RefreshCw, Layers } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import Image from "next/image";

export default function ThumbnailMakerPage() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<GenerateThumbnailImageOutput | null>(null);
  const [formData, setFormData] = useState({
    videoTopic: "",
    thumbnailStyle: "vibrant",
    emotion: "exciting",
    mainSubject: "",
    format: "16:9" as "16:9" | "9:16"
  });

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.videoTopic) return;
    
    setLoading(true);
    try {
      const output = await generateThumbnailImage(formData);
      setResult(output);
      toast({ title: "Visualizing Success!", description: "Your AI thumbnail has been generated." });
    } catch (error: any) {
      console.error(error);
      toast({ 
        title: "Generation Failed", 
        description: error.message || "Our artists are currently unavailable. Please try again.", 
        variant: "destructive" 
      });
    } finally {
      setLoading(false);
    }
  };

  const downloadImage = () => {
    if (!result) return;
    const link = document.createElement('a');
    link.href = result.thumbnailImage;
    link.download = `thumbnail-${Date.now()}.png`;
    link.click();
  };

  // Calculate display dimensions based on format to prevent layout shift
  const displayWidth = formData.format === '16:9' ? 1280 : 720;
  const displayHeight = formData.format === '16:9' ? 720 : 1280;

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="space-y-1">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <ImageIcon className="w-8 h-8 text-green-400" /> Thumbnail Visualizer
        </h1>
        <p className="text-muted-foreground">Turn your video concept into eye-catching visuals.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <Card className="lg:col-span-4 h-fit bg-card/50 border-white/5">
          <CardHeader>
            <CardTitle>Creative Direction</CardTitle>
            <CardDescription>Describe your visual goal</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleGenerate} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="topic">Video Topic / Title</Label>
                <Input 
                  id="topic" 
                  placeholder="e.g. How to Bake a Cake" 
                  value={formData.videoTopic}
                  onChange={e => setFormData({...formData, videoTopic: e.target.value})}
                  className="bg-muted/50 border-white/10"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="subject">Main Subject</Label>
                <Input 
                  id="subject" 
                  placeholder="e.g. A chef holding a golden cake" 
                  value={formData.mainSubject}
                  onChange={e => setFormData({...formData, mainSubject: e.target.value})}
                  className="bg-muted/50 border-white/10"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="style">Style</Label>
                  <Select value={formData.thumbnailStyle} onValueChange={v => setFormData({...formData, thumbnailStyle: v})}>
                    <SelectTrigger className="bg-muted/50 border-white/10">
                      <SelectValue placeholder="Style" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="vibrant">Vibrant</SelectItem>
                      <SelectItem value="minimalist">Minimalist</SelectItem>
                      <SelectItem value="cinematic">Cinematic</SelectItem>
                      <SelectItem value="cartoon">Cartoon</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="emotion">Emotion</Label>
                  <Select value={formData.emotion} onValueChange={v => setFormData({...formData, emotion: v})}>
                    <SelectTrigger className="bg-muted/50 border-white/10">
                      <SelectValue placeholder="Emotion" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="exciting">Exciting</SelectItem>
                      <SelectItem value="mysterious">Mysterious</SelectItem>
                      <SelectItem value="humorous">Humorous</SelectItem>
                      <SelectItem value="dramatic">Dramatic</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Aspect Ratio</Label>
                <div className="grid grid-cols-2 gap-2">
                  <Button 
                    type="button" 
                    variant={formData.format === '16:9' ? 'default' : 'outline'}
                    onClick={() => setFormData({...formData, format: '16:9'})}
                    className="w-full text-xs h-10 border-white/10"
                  >
                    16:9 (Long)
                  </Button>
                  <Button 
                    type="button" 
                    variant={formData.format === '9:16' ? 'default' : 'outline'}
                    onClick={() => setFormData({...formData, format: '9:16'})}
                    className="w-full text-xs h-10 border-white/10"
                  >
                    9:16 (Shorts)
                  </Button>
                </div>
              </div>
              <Button type="submit" disabled={loading} className="w-full bg-primary hover:bg-primary/90 neon-glow-primary">
                {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Sparkles className="w-4 h-4 mr-2" />}
                Generate Artwork
              </Button>
            </form>
          </CardContent>
        </Card>

        <div className="lg:col-span-8 space-y-6">
          {!result && !loading && (
            <Card className="border-dashed border-white/10 bg-muted/5 flex items-center justify-center aspect-video rounded-xl">
              <div className="text-center space-y-2 opacity-50">
                <ImageIcon className="w-16 h-16 mx-auto mb-4" />
                <p>Your masterpiece will appear here</p>
              </div>
            </Card>
          )}

          {loading && (
            <Card className="bg-card/50 border-white/5 aspect-video flex flex-col items-center justify-center space-y-6 p-12">
              <div className="relative">
                <div className="w-24 h-24 rounded-full border-t-2 border-primary animate-spin" />
                <ImageIcon className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 text-primary" />
              </div>
              <div className="text-center space-y-2">
                <p className="text-xl font-headline font-bold">Dreaming up pixels...</p>
                <p className="text-muted-foreground">Processing high-resolution creative assets</p>
              </div>
            </Card>
          )}

          {result && (
            <div className="space-y-6 animate-in zoom-in-95 duration-500">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/5 bg-black">
                <Image 
                  unoptimized
                  src={result.thumbnailImage} 
                  alt="AI Generated Thumbnail" 
                  width={displayWidth} 
                  height={displayHeight}
                  className="w-full object-contain max-h-[600px]"
                  priority
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 hover:opacity-100 transition-opacity flex items-end p-8">
                   <div className="flex gap-4 w-full justify-center">
                    <Button onClick={downloadImage} size="lg" className="bg-primary hover:bg-primary/90">
                      <Download className="w-5 h-5 mr-2" /> Download HQ
                    </Button>
                    <Button onClick={handleGenerate} variant="secondary" size="lg">
                      <RefreshCw className="w-5 h-5 mr-2" /> Regenerate
                    </Button>
                   </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="bg-card/50 border-white/5">
                  <CardHeader>
                    <CardTitle className="text-sm uppercase tracking-widest text-accent flex items-center gap-2">
                      <Sparkles className="w-4 h-4" /> AI Generation Prompt
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground italic leading-relaxed">
                      {result.thumbnailPrompt}
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-card/50 border-white/5">
                  <CardHeader>
                    <CardTitle className="text-sm uppercase tracking-widest text-primary flex items-center gap-2">
                      <Layers className="w-4 h-4" /> Text Overlay Ideas
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {result.thumbnailTextSuggestions.map((text, i) => (
                        <Badge key={i} variant="outline" className="px-3 py-1 bg-white/5 border-white/10 hover:border-primary cursor-pointer transition-colors">
                          {text}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="flex justify-center">
                <Button size="lg" variant="outline" className="border-accent/30 text-accent hover:bg-accent/10">
                  <Save className="w-5 h-5 mr-2" /> Save Asset to Vault
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
