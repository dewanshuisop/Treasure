"use client";

import { useState } from "react";
import { generateVideoScript, type GenerateVideoScriptOutput } from "@/ai/flows/generate-video-script-flow";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Loader2, Copy, Download, Save, Sparkles, FileText, Share2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";

export default function ScriptMakerPage() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<GenerateVideoScriptOutput | null>(null);
  const [formData, setFormData] = useState({
    videoTopic: "",
    targetAudience: "",
    scriptLength: "medium",
    videoType: "Long Form" as "Long Form" | "Short Form"
  });

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.videoTopic) return;
    
    setLoading(true);
    try {
      const output = await generateVideoScript(formData);
      setResult(output);
      toast({ title: "Treasure Found!", description: "Your script has been generated successfully." });
    } catch (error) {
      toast({ title: "Error", description: "Failed to generate script. Please try again.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    if (!result) return;
    const text = `
HOOK: ${result.hook}
INTRODUCTION: ${result.introduction}
CONTENT:
${result.mainContent.join('\n\n')}
ENGAGEMENT QUESTIONS:
${result.engagementQuestions.join('\n')}
CALL TO ACTION: ${result.callToAction}
CONCLUSION: ${result.conclusion}
    `.trim();
    navigator.clipboard.writeText(text);
    toast({ title: "Copied!", description: "Script copied to clipboard." });
  };

  const downloadTxt = () => {
    if (!result) return;
    const text = `
 Dewanshuisop's Treasure - Script Sculptor Result
 ===========================================
 Topic: ${formData.videoTopic}
 Target: ${formData.targetAudience}
 
 HOOK: ${result.hook}
 
 INTRODUCTION: ${result.introduction}
 
 MAIN CONTENT:
 ${result.mainContent.join('\n\n')}
 
 QUESTIONS:
 ${result.engagementQuestions.join('\n')}
 
 CTA: ${result.callToAction}
 
 CONCLUSION: ${result.conclusion}
    `.trim();
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `script-${formData.videoTopic.replace(/\s+/g, '-').toLowerCase()}.txt`;
    a.click();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <FileText className="w-8 h-8 text-primary" /> Script Sculptor
        </h1>
        <p className="text-muted-foreground text-lg">
          Craft high-converting YouTube scripts tailored for maximum engagement.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <Card className="md:col-span-1 bg-card/50 border-white/5 h-fit sticky top-24">
          <CardHeader>
            <CardTitle>Configuration</CardTitle>
            <CardDescription>Define your video details</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleGenerate} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="topic">Video Topic</Label>
                <Input 
                  id="topic" 
                  placeholder="e.g. 10 Life Hacks for Students" 
                  value={formData.videoTopic}
                  onChange={e => setFormData({...formData, videoTopic: e.target.value})}
                  className="bg-muted/50 border-white/10"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="audience">Target Audience</Label>
                <Input 
                  id="audience" 
                  placeholder="e.g. Tech Enthusiasts" 
                  value={formData.targetAudience}
                  onChange={e => setFormData({...formData, targetAudience: e.target.value})}
                  className="bg-muted/50 border-white/10"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="length">Script Length</Label>
                <Select value={formData.scriptLength} onValueChange={v => setFormData({...formData, scriptLength: v})}>
                  <SelectTrigger className="bg-muted/50 border-white/10">
                    <SelectValue placeholder="Select length" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="short">Short (1-2 min)</SelectItem>
                    <SelectItem value="medium">Medium (5-8 min)</SelectItem>
                    <SelectItem value="long">Long (10-15 min)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="type">Format</Label>
                <Select value={formData.videoType} onValueChange={v => setFormData({...formData, videoType: v as any})}>
                  <SelectTrigger className="bg-muted/50 border-white/10">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Long Form">YouTube Long Form</SelectItem>
                    <SelectItem value="Short Form">Shorts / Reels / TikTok</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button type="submit" disabled={loading} className="w-full bg-primary hover:bg-primary/90 neon-glow-primary">
                {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Sparkles className="w-4 h-4 mr-2" />}
                Sculpt Script
              </Button>
            </form>
          </CardContent>
        </Card>

        <div className="md:col-span-2 space-y-6">
          {!result && !loading && (
            <Card className="border-dashed border-white/10 bg-transparent h-[400px] flex items-center justify-center">
              <div className="text-center space-y-4 max-w-xs">
                <Sparkles className="w-12 h-12 text-primary/30 mx-auto" />
                <p className="text-muted-foreground italic">Input your details and let the AI sculpt your next viral script.</p>
              </div>
            </Card>
          )}

          {loading && (
            <Card className="bg-card/50 border-white/5 p-12">
              <div className="flex flex-col items-center justify-center space-y-4 text-center">
                <Loader2 className="w-10 h-10 text-primary animate-spin" />
                <p className="font-medium text-primary animate-pulse">dewanshuisop is using his brain...</p>
                <p className="text-sm text-muted-foreground">Synthesizing script components. This may take up to 20 seconds.</p>
              </div>
            </Card>
          )}

          {result && (
            <div className="space-y-6 animate-in fade-in duration-500">
              <div className="flex justify-end gap-2">
                <Button variant="outline" size="sm" onClick={copyToClipboard}><Copy className="w-4 h-4 mr-2" /> Copy</Button>
                <Button variant="outline" size="sm" onClick={downloadTxt}><Download className="w-4 h-4 mr-2" /> Download</Button>
                <Button size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90"><Save className="w-4 h-4 mr-2" /> Save to Vault</Button>
              </div>

              <Card className="bg-card border-white/5 overflow-hidden">
                <div className="bg-primary/10 border-b border-white/5 px-6 py-4 flex items-center justify-between">
                  <Badge variant="outline" className="bg-primary/20 text-primary border-primary/30 uppercase tracking-widest text-[10px]">The Hook</Badge>
                  <Share2 className="w-4 h-4 text-muted-foreground" />
                </div>
                <CardContent className="p-6">
                  <p className="text-xl font-headline font-bold text-primary italic leading-relaxed">
                    "{result.hook}"
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-card border-white/5">
                <CardHeader>
                  <CardTitle className="text-lg">Introduction</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground leading-relaxed">{result.introduction}</p>
                </CardContent>
              </Card>

              <Card className="bg-card border-white/5">
                <CardHeader>
                  <CardTitle className="text-lg">Main Content</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {result.mainContent.map((paragraph, i) => (
                    <p key={i} className="leading-relaxed border-l-2 border-primary/20 pl-4">{paragraph}</p>
                  ))}
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="bg-card/50 border-white/5">
                  <CardHeader>
                    <CardTitle className="text-sm uppercase tracking-widest text-accent">Audience Engagement</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {result.engagementQuestions.map((q, i) => (
                        <li key={i} className="text-sm flex gap-2">
                          <span className="text-accent">?</span> {q}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
                <Card className="bg-card/50 border-white/5">
                  <CardHeader>
                    <CardTitle className="text-sm uppercase tracking-widest text-red-400">Call to Action</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm italic">"{result.callToAction}"</p>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-muted/20 border-white/5">
                <CardHeader>
                  <CardTitle className="text-lg">Conclusion</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground italic">{result.conclusion}</p>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
