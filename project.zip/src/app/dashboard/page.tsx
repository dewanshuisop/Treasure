import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Lightbulb, Plus, Sparkles, TrendingUp, Users, Clock } from "lucide-react";
import Link from "next/link";

function DiscordIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
      <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515a.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0a12.64 12.64 0 0 0-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057a19.9 19.9 0 0 0 5.993 3.03a.078.078 0 0 0 .084-.028a14.09 14.09 0 0 0 1.226-1.994a.076.076 0 0 0-.041-.106a13.107 13.107 0 0 1-1.872-.892a.077.077 0 0 1-.008-.128a10.2 10.2 0 0 0 .372-.292a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127a12.299 12.299 0 0 1-1.873.892a.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028a19.839 19.839 0 0 0 6.002-3.03a.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.956-2.419 2.157-2.419c1.21 0 2.176 1.086 2.157 2.419c0 1.334-.947 2.419-2.157 2.419zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.955-2.419 2.157-2.419c1.21 0 2.176 1.086 2.157 2.419c0 1.334-.946 2.419-2.157 2.419z" />
    </svg>
  );
}

export default function DashboardPage() {
  const stats = [
    { label: "Total Scripts", value: "24", icon: FileText, color: "text-primary" },
    { label: "Viral Ideas", value: "156", icon: Lightbulb, color: "text-yellow-400" },
  ];

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            Welcome back, Creator <Sparkles className="w-6 h-6 text-primary animate-pulse" />
          </h1>
          <p className="text-muted-foreground mt-1">Ready to find your next viral treasure?</p>
        </div>
        <Button className="bg-primary hover:bg-primary/90 neon-glow-primary font-headline" asChild>
          <Link href="/dashboard/script-maker"><Plus className="w-4 h-4 mr-2" /> New Project</Link>
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {stats.map((stat, i) => (
          <Card key={i} className="bg-card/50 border-white/5">
            <CardContent className="p-6 flex items-center gap-4">
              <div className={`p-3 rounded-lg bg-white/5 ${stat.color}`}>
                <stat.icon className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
                <p className="text-2xl font-bold">{stat.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <Card className="bg-card/50 border-white/5">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Recent Treasures</CardTitle>
                <CardDescription>Your most recently modified projects</CardDescription>
              </div>
              <Button variant="ghost" size="sm" asChild>
                <Link href="/dashboard/vault">View All</Link>
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 rounded-lg hover:bg-white/5 transition-colors border border-transparent hover:border-white/5">
                  <div className="flex items-center gap-4">
                    <div className="p-2 rounded bg-muted">
                      <FileText className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-sm">10 AI Tools for 2024</p>
                      <p className="text-xs text-muted-foreground">Script • 2 hours ago</p>
                    </div>
                  </div>
                  <span className="text-xs font-medium px-2 py-1 rounded bg-white/10">Saved</span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg hover:bg-white/5 transition-colors border border-transparent hover:border-white/5">
                  <div className="flex items-center gap-4">
                    <div className="p-2 rounded bg-muted">
                      <Lightbulb className="w-4 h-4 text-yellow-400" />
                    </div>
                    <div>
                      <p className="font-medium text-sm">Cooking Tutorial</p>
                      <p className="text-xs text-muted-foreground">Idea • 2 days ago</p>
                    </div>
                  </div>
                  <span className="text-xs font-medium px-2 py-1 rounded bg-white/10">Saved</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-primary/10 to-accent/5 border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-primary" /> Viral Growth
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Users of Dewanshuisop's Treasure see an average 40% increase in watch time within the first 30 days.
              </p>
              <Button size="sm" variant="outline" className="w-full border-primary/30">Learn Retention Secrets</Button>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="bg-card/50 border-[#5865F2]/40 border-2 shadow-[0_0_15px_-5px_rgba(88,101,242,0.5)]">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-[#5865F2]">
                <DiscordIcon className="w-6 h-6" /> Support & Feedback
              </CardTitle>
              <CardDescription className="text-xs font-bold uppercase tracking-widest text-[#5865F2]/70">Get feedback here</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm leading-relaxed">
                Connect directly with the creator community. Share your scripts, get critiques, and help us improve the treasure!
              </p>
              <Button className="w-full bg-[#5865F2] hover:bg-[#5865F2]/90 text-white font-bold" asChild>
                <Link href="https://discordapp.com/users/831023230206345277" target="_blank">
                  Open Discord Chat
                </Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-white/5">
            <CardHeader>
              <CardTitle className="text-sm">Usage Limits</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-medium">
                  <span>AI Computations</span>
                  <span>78 / 100</span>
                </div>
                <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary" style={{ width: '78%' }} />
                </div>
              </div>
              <Button variant="outline" size="sm" className="w-full border-primary/20">Upgrade Plan</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
