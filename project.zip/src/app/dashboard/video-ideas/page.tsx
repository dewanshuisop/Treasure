"use client";

import { useState } from "react";
import { generateVideoIdeas, type GenerateVideoIdeasOutput } from "@/ai/flows/generate-video-ideas-flow";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Loader2, Lightbulb, TrendingUp, Gauge, Eye, ChevronRight, Sparkles, Filter } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";

export default function VideoIdeasPage() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<GenerateVideoIdeasOutput | null>(null);
  const [formData, setFormData] = useState({
    channelNiche: "",
    targetAudience: "",
    contentType: ""
  });

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.channelNiche) return;
    
    setLoading(true);
    try {
      const output = await generateVideoIdeas(formData);
      setResult(output);
      toast({ title: "Jackpot!", description: "We've generated fresh viral ideas for your niche." });
    } catch (error) {
      toast({ title: "Error", description: "Failed to generate ideas. Please try again.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const getViralColor = (score: number) => {
    if (score >= 8) return "text-green-400";
    if (score >= 5) return "text-yellow-400";
    return "text-red-400";
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Lightbulb className="w-8 h-8 text-yellow-400" /> Viral Niche Explorer
          </h1>
          <p className="text-muted-foreground">Find your next million-view video idea.</p>
        </div>
        {result && (
          <Button variant="outline" className="border-white/10" onClick={() => setResult(null)}>
            <Filter className="w-4 h-4 mr-2" /> Reset Search
          </Button>
        )}
      </div>

      {!result && !loading && (
        <Card className="bg-card/50 border-white/5 max-w-2xl mx-auto">
          <CardHeader>
            <CardTitle>Niche Insights</CardTitle>
            <CardDescription>Tell us about your channel to get tailored ideas</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleGenerate} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="niche">Channel Niche</Label>
                <Input 
                  id="niche" 
                  placeholder="e.g. Sustainable Fashion, Retro Gaming" 
                  value={formData.channelNiche}
                  onChange={e => setFormData({...formData, channelNiche: e.target.value})}
                  className="h-12 bg-muted/50 border-white/10"
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="audience">Target Audience</Label>
                  <Input 
                    id="audience" 
                    placeholder="e.g. Young professionals" 
                    value={formData.targetAudience}
                    onChange={e => setFormData({...formData, targetAudience: e.target.value})}
                    className="h-12 bg-muted/50 border-white/10"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="content">Preferred Content Type</Label>
                  <Input 
                    id="content" 
                    placeholder="e.g. Tutorials, Documentaries" 
                    value={formData.contentType}
                    onChange={e => setFormData({...formData, contentType: e.target.value})}
                    className="h-12 bg-muted/50 border-white/10"
                  />
                </div>
              </div>
              <Button type="submit" disabled={loading} className="w-full h-12 text-lg bg-primary hover:bg-primary/90 neon-glow-primary">
                {loading ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <Sparkles className="w-5 h-5 mr-2" />}
                Generate Viral Treasure
              </Button>
            </form>
          </CardContent>
        </Card>
      )}

      {loading && (
        <div className="space-y-6">
          <div className="flex flex-col items-center justify-center p-8 text-center space-y-4">
            <Loader2 className="w-12 h-12 text-yellow-400 animate-spin" />
            <h2 className="text-2xl font-bold text-yellow-400 animate-pulse">dewanshuisop is using his brain...</h2>
            <p className="text-muted-foreground">Scouring the niches for viral gold...</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1,2,3,4,5,6].map(i => (
              <Card key={i} className="h-64 bg-card/50 border-white/5 animate-pulse">
                <div className="p-6 space-y-4">
                  <div className="h-6 w-3/4 bg-muted rounded" />
                  <div className="h-4 w-full bg-muted rounded" />
                  <div className="h-4 w-5/6 bg-muted rounded" />
                  <div className="h-20 w-full bg-muted/50 rounded mt-4" />
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {result && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-in zoom-in-95 duration-500">
          {result.videoIdeas.map((idea, idx) => (
            <Card key={idx} className="group flex flex-col h-full bg-card hover:bg-muted/30 transition-all border-white/5 hover:border-primary/50 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-2">
                <Badge variant="secondary" className="bg-background/80 backdrop-blur-sm border-white/5">
                  #{idx + 1}
                </Badge>
              </div>
              <CardHeader>
                <CardTitle className="text-xl leading-tight group-hover:text-primary transition-colors pr-8">
                  {idea.title}
                </CardTitle>
                <div className="flex flex-wrap gap-2 pt-2">
                  <div className="flex items-center gap-1 text-[10px] uppercase tracking-tighter font-bold">
                    <TrendingUp className={`w-3 h-3 ${getViralColor(idea.viralScore)}`} />
                    Viral: <span className={getViralColor(idea.viralScore)}>{idea.viralScore}/10</span>
                  </div>
                  <div className="flex items-center gap-1 text-[10px] uppercase tracking-tighter font-bold">
                    <Gauge className="w-3 h-3 text-accent" />
                    Diff: <span className="text-accent">{idea.difficultyScore}/10</span>
                  </div>
                  <div className="flex items-center gap-1 text-[10px] uppercase tracking-tighter font-bold">
                    <Eye className="w-3 h-3 text-primary" />
                    Potent: <span className="text-primary">{idea.estimatedViewsPotential}</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="flex-1 space-y-4">
                <div className="bg-muted/50 p-3 rounded-lg border border-white/5">
                  <p className="text-xs font-bold uppercase text-muted-foreground mb-1">Hook</p>
                  <p className="text-sm italic">"{idea.hook}"</p>
                </div>
                <p className="text-sm text-muted-foreground line-clamp-3">
                  {idea.shortDescription}
                </p>
                <div className="pt-2">
                   <p className="text-xs font-bold uppercase text-muted-foreground mb-1">Thumbnail Concept</p>
                   <p className="text-xs text-muted-foreground italic border-l-2 border-accent/20 pl-2">
                    {idea.thumbnailIdea}
                   </p>
                </div>
              </CardContent>
              <div className="p-4 border-t border-white/5 mt-auto flex justify-between items-center bg-muted/20">
                <Button variant="ghost" size="sm" className="text-primary hover:text-primary hover:bg-primary/10">
                  Save Idea
                </Button>
                <Button size="sm" className="bg-primary/20 hover:bg-primary/30 text-primary border-primary/30" asChild>
                  <Link href={`/dashboard/script-maker?topic=${encodeURIComponent(idea.title)}`}>
                    Write Script <ChevronRight className="w-4 h-4 ml-1" />
                  </Link>
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
