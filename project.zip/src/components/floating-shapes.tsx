'use client';

import { useEffect, useState } from 'react';

interface Shape {
  id: number;
  left: string;
  duration: string;
  delay: string;
  size: string;
  type: 'cube' | 'sphere' | 'triangle';
}

export function FloatingShapes() {
  const [shapes, setShapes] = useState<Shape[]>([]);

  useEffect(() => {
    // Generate more shapes for better visibility
    const newShapes: Shape[] = Array.from({ length: 25 }).map((_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      duration: `${20 + Math.random() * 30}s`,
      delay: `${Math.random() * -40}s`, // Negative delay to start them mid-animation
      size: `${10 + Math.random() * 40}px`,
      type: i % 3 === 0 ? 'cube' : i % 3 === 1 ? 'sphere' : 'triangle',
    }));
    setShapes(newShapes);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {shapes.map((shape) => (
        <div
          key={shape.id}
          className="falling-shape bg-primary/20 border border-primary/30 backdrop-blur-[2px]"
          style={{
            left: shape.left,
            animationDuration: shape.duration,
            animationDelay: shape.delay,
            width: shape.size,
            height: shape.size,
            borderRadius: shape.type === 'sphere' ? '50%' : shape.type === 'cube' ? '4px' : '0',
            clipPath: shape.type === 'triangle' ? 'polygon(50% 0%, 0% 100%, 100% 100%)' : 'none',
          }}
        />
      ))}
    </div>
  );
}