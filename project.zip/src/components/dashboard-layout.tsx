"use client";

import { 
  SidebarProvider, 
  Sidebar, 
  SidebarContent, 
  SidebarHeader, 
  SidebarFooter, 
  SidebarMenu, 
  SidebarMenuItem, 
  SidebarMenuButton, 
  SidebarGroup,
  SidebarGroupLabel,
  SidebarTrigger,
  SidebarInset
} from "@/components/ui/sidebar";
import { 
  FileText, 
  Wand2, 
  Lightbulb, 
  LayoutDashboard, 
  Settings, 
  LogOut, 
  Sparkles,
  Search,
  History,
  Archive
} from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";

function DiscordIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
      <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515a.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0a12.64 12.64 0 0 0-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057a19.9 19.9 0 0 0 5.993 3.03a.078.078 0 0 0 .084-.028a14.09 14.09 0 0 0 1.226-1.994a.076.076 0 0 0-.041-.106a13.107 13.107 0 0 1-1.872-.892a.077.077 0 0 1-.008-.128a10.2 10.2 0 0 0 .372-.292a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127a12.299 12.299 0 0 1-1.873.892a.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028a19.839 19.839 0 0 0 6.002-3.03a.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.956-2.419 2.157-2.419c1.21 0 2.176 1.086 2.157 2.419c0 1.334-.947 2.419-2.157 2.419zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.955-2.419 2.157-2.419c1.21 0 2.176 1.086 2.157 2.419c0 1.334-.946 2.419-2.157 2.419z" />
    </svg>
  );
}

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  const menuItems = [
    { title: "Overview", icon: LayoutDashboard, href: "/dashboard" },
    { title: "Script Sculptor", icon: FileText, href: "/dashboard/script-maker" },
    { title: "Retention Optimizer", icon: Wand2, href: "/dashboard/script-improver" },
    { title: "Viral Explorer", icon: Lightbulb, href: "/dashboard/video-ideas" },
  ];

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background/0">
        <Sidebar className="border-r border-white/5 bg-card/80 backdrop-blur-md" collapsible="icon">
          <SidebarHeader className="h-16 flex items-center px-6">
            <Link href="/" className="flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-primary" />
              <span className="font-headline font-bold text-lg group-data-[collapsible=icon]:hidden">
                Dewanshuisop's Treasure
              </span>
            </Link>
          </SidebarHeader>
          <SidebarContent>
            <SidebarGroup>
              <SidebarGroupLabel className="px-6 group-data-[collapsible=icon]:hidden">Creator Tools</SidebarGroupLabel>
              <SidebarMenu>
                {menuItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton 
                      asChild 
                      isActive={pathname === item.href}
                      tooltip={item.title}
                      className="transition-all hover:bg-primary/10 hover:text-primary data-[active=true]:bg-primary/20 data-[active=true]:text-primary"
                    >
                      <Link href={item.href}>
                        <item.icon className="w-5 h-5" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroup>

            <SidebarGroup className="mt-auto">
              <SidebarGroupLabel className="px-6 group-data-[collapsible=icon]:hidden">Storage</SidebarGroupLabel>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild tooltip="The Vault" className="hover:text-accent">
                    <Link href="/dashboard/vault">
                      <Archive className="w-5 h-5" />
                      <span>The Vault</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild tooltip="History" className="hover:text-accent">
                    <Link href="/dashboard/history">
                      <History className="w-5 h-5" />
                      <span>Recent History</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroup>
          </SidebarContent>
          <SidebarFooter className="border-t border-white/5 p-4">
            <div className="flex items-center gap-3 px-2">
              <Avatar className="w-8 h-8 border border-primary/20">
                <AvatarImage src="https://picsum.photos/seed/user1/40/40" />
                <AvatarFallback>DT</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0 group-data-[collapsible=icon]:hidden">
                <p className="text-sm font-medium truncate">Creator Pro</p>
                <p className="text-xs text-muted-foreground truncate">pro@dewanshuisop.ai</p>
              </div>
            </div>
            <SidebarMenu className="mt-4">
               <SidebarMenuItem>
                <SidebarMenuButton asChild tooltip="Settings" className="hover:bg-accent/10">
                  <Link href="/dashboard/settings">
                    <Settings className="w-4 h-4" />
                    <span>Settings</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton tooltip="Logout" className="text-destructive hover:bg-destructive/10">
                  <LogOut className="w-4 h-4" />
                  <span>Logout</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarFooter>
        </Sidebar>

        <SidebarInset className="flex-1 flex flex-col min-w-0 bg-transparent">
          <header className="h-16 flex items-center justify-between px-6 border-b border-white/5 sticky top-0 bg-background/50 backdrop-blur-md z-40">
            <div className="flex items-center gap-4">
              <SidebarTrigger />
              <Separator orientation="vertical" className="h-6" />
              <div className="relative w-64 md:w-96 hidden sm:block">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input 
                  placeholder="Search your treasure..." 
                  className="pl-10 h-9 bg-card/50 border-white/5 focus-visible:ring-primary/50" 
                />
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Button 
                variant="outline" 
                size="sm" 
                className="flex items-center gap-2 border-[#5865F2]/50 text-[#5865F2] hover:bg-[#5865F2]/10 transition-all font-bold"
                asChild
              >
                <Link href="https://discordapp.com/users/831023230206345277" target="_blank">
                  <DiscordIcon className="w-4 h-4" />
                  <span className="hidden lg:inline">get feedback here</span>
                  <span className="lg:hidden">feedback</span>
                </Link>
              </Button>
              <Separator orientation="vertical" className="h-6 hidden lg:block" />
              <div className="flex flex-col items-end mr-2 hidden md:flex">
                <span className="text-xs text-muted-foreground">Plan Status</span>
                <span className="text-xs font-bold text-primary">CREATOR PRO</span>
              </div>
              <Button size="sm" className="bg-primary hover:bg-primary/90 hidden sm:flex">Upgrade</Button>
            </div>
          </header>
          <main className="flex-1 p-6 lg:p-10 max-w-7xl mx-auto w-full relative z-10">
            {children}
          </main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}