'use server';
/**
 * @fileOverview A Genkit flow for generating realistic AI-powered voiceovers from script text.
 *
 * - generateVoiceoverAudio - A function that handles the voiceover generation process.
 * - GenerateVoiceoverAudioInput - The input type for the generateVoiceoverAudio function.
 * - GenerateVoiceoverAudioOutput - The return type for the generateVoiceoverAudio function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import { googleAI } from '@genkit-ai/google-genai';
import wav from 'wav';

const GenerateVoiceoverAudioInputSchema = z.object({
  scriptText: z.string().describe('The script text to convert to speech.'),
  language: z.string().describe('The language of the script (e.g., "en-US", "es-ES"). Currently, only "en-US" is fully supported for detailed voice style mapping.'),
  voiceGender: z.enum(['MALE', 'FEMALE', 'NEUTRAL']).describe('The desired gender of the voice.'),
  voiceStyle: z.enum(['Storytelling', 'Documentary', 'Energetic', 'Professional', 'Motivational']).describe('The desired style of the voice.'),
});
export type GenerateVoiceoverAudioInput = z.infer<typeof GenerateVoiceoverAudioInputSchema>;

const GenerateVoiceoverAudioOutputSchema = z.object({
  audioDataUri: z.string().describe('The generated audio as a WAV data URI (data:audio/wav;base64,...).'),
});
export type GenerateVoiceoverAudioOutput = z.infer<typeof GenerateVoiceoverAudioOutputSchema>;

/**
 * Maps user preferences to valid Gemini TTS voice names.
 * Supported Gemini voices: Algenib, Achernar, Rigel, Capella, Vega, Castor, Sirius, Canopus.
 */
function selectGeminiVoice(
  gender: GenerateVoiceoverAudioInput['voiceGender'],
  style: GenerateVoiceoverAudioInput['voiceStyle']
): string {
  switch (gender) {
    case 'MALE':
      switch (style) {
        case 'Storytelling': return 'Castor';
        case 'Motivational':
        case 'Energetic': return 'Algenib';
        case 'Documentary':
        case 'Professional': return 'Rigel';
        default: return 'Castor';
      }
    case 'FEMALE':
      switch (style) {
        case 'Storytelling': return 'Vega';
        case 'Motivational':
        case 'Energetic': return 'Achernar';
        case 'Documentary':
        case 'Professional': return 'Capella';
        default: return 'Vega';
      }
    case 'NEUTRAL':
    default:
      return 'Sirius';
  }
}

/**
 * Converts PCM audio buffer to WAV format using the wav package.
 */
async function toWav(
  pcmData: Buffer,
  channels = 1,
  rate = 24000,
  sampleWidth = 2
): Promise<string> {
  return new Promise((resolve, reject) => {
    const writer = new wav.Writer({
      channels,
      sampleRate: rate,
      bitDepth: sampleWidth * 8,
    });

    let bufs = [] as any[];
    writer.on('error', reject);
    writer.on('data', function (d) {
      bufs.push(d);
    });
    writer.on('end', function () {
      resolve(Buffer.concat(bufs).toString('base64'));
    });

    writer.write(pcmData);
    writer.end();
  });
}

const generateVoiceoverAudioFlow = ai.defineFlow(
  {
    name: 'generateVoiceoverAudioFlow',
    inputSchema: GenerateVoiceoverAudioInputSchema,
    outputSchema: GenerateVoiceoverAudioOutputSchema,
  },
  async (input) => {
    const { scriptText, voiceGender, voiceStyle } = input;

    // Use Gemini-native voice names
    const voiceName = selectGeminiVoice(voiceGender, voiceStyle);

    const { media } = await ai.generate({
      model: googleAI.model('gemini-2.5-flash-preview-tts'),
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voiceName },
          },
        },
      },
      prompt: scriptText,
    });

    if (!media || !media.url) {
      throw new Error('No audio media returned from the TTS model.');
    }

    const audioBuffer = Buffer.from(
      media.url.substring(media.url.indexOf(',') + 1),
      'base64'
    );

    const wavBase64 = await toWav(audioBuffer);

    return {
      audioDataUri: 'data:audio/wav;base64,' + wavBase64,
    };
  }
);

export async function generateVoiceoverAudio(
  input: GenerateVoiceoverAudioInput
): Promise<GenerateVoiceoverAudioOutput> {
  return generateVoiceoverAudioFlow(input);
}
