'use server';
/**
 * @fileOverview An AI agent that improves existing YouTube scripts based on specified improvement options.
 *
 * - improveExistingScript - A function that handles the script improvement process.
 * - ImproveExistingScriptInput - The input type for the improveExistingScript function.
 * - ImproveExistingScriptOutput - The return type for the improveExistingScript function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

// Input Schema
const ImproveExistingScriptInputSchema = z.object({
  existingScript: z.string().describe('The existing YouTube script text to be improved.'),
  improvementOption: z.enum(['More Engaging', 'More Emotional', 'More Viral', 'More Professional', 'More Educational']).describe('The desired improvement style for the script.'),
});
export type ImproveExistingScriptInput = z.infer<typeof ImproveExistingScriptInputSchema>;

// Output Schema
const ImproveExistingScriptOutputSchema = z.object({
  improvedScript: z.string().describe('The AI-generated improved version of the script.'),
  suggestions: z.array(z.string()).describe('A list of specific suggestions or changes made to improve the script.'),
});
export type ImproveExistingScriptOutput = z.infer<typeof ImproveExistingScriptOutputSchema>;

export async function improveExistingScript(input: ImproveExistingScriptInput): Promise<ImproveExistingScriptOutput> {
  return improveExistingScriptFlow(input);
}

const improveExistingScriptPrompt = ai.definePrompt({
  name: 'improveExistingScriptPrompt',
  input: {schema: ImproveExistingScriptInputSchema},
  output: {schema: ImproveExistingScriptOutputSchema},
  prompt: `You are an expert YouTube script editor specializing in making content more compelling and audience-retaining. Your task is to revise the provided YouTube script, focusing on making it "{{{improvementOption}}}".

Specifically, ensure the improved script includes:
- A stronger hook to immediately grab attention.
- Better flow and transitions between sections.
- Retention-boosting techniques throughout.
- More engagement prompts (e.g., questions, calls to comment).

Return the improved script and a list of specific improvements made, such as "Strengthened the opening hook", "Added a rhetorical question", or "Improved sentence structure for better flow".

Original Script:
{{{existingScript}}}`,
});

const improveExistingScriptFlow = ai.defineFlow(
  {
    name: 'improveExistingScriptFlow',
    inputSchema: ImproveExistingScriptInputSchema,
    outputSchema: ImproveExistingScriptOutputSchema,
  },
  async input => {
    const {output} = await improveExistingScriptPrompt(input);
    if (!output) {
      throw new Error('Failed to generate improved script.');
    }
    return output;
  }
);
