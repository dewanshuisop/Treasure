'use server';
/**
 * @fileOverview A Genkit flow for generating complete YouTube video scripts based on user-provided details.
 *
 * - generateVideoScript - A function that generates a YouTube video script.
 * - GenerateVideoScriptInput - The input type for the generateVideoScript function.
 * - GenerateVideoScriptOutput - The return type for the generateVideoScript function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateVideoScriptInputSchema = z.object({
  videoTopic: z.string().describe('The main topic of the YouTube video.'),
  targetAudience: z.string().describe('The intended audience for the video.'),
  scriptLength: z
    .string()
    .describe(
      'Desired length of the script (e.g., "short", "medium", "long", "5 minutes").'
    ),
  videoType: z.enum(['Short Form', 'Long Form']).describe('The type of video.'),
});
export type GenerateVideoScriptInput = z.infer<
  typeof GenerateVideoScriptInputSchema
>;

const GenerateVideoScriptOutputSchema = z.object({
  hook: z
    .string()
    .describe('An engaging opening statement to grab the viewer\'s attention.'),
  introduction: z
    .string()
    .describe('Introduces the video topic and what viewers can expect.'),
  mainContent: z
    .array(z.string())
    .describe('Key sections or paragraphs covering the main topic.'),
  engagementQuestions: z
    .array(z.string())
    .describe(
      'Questions to ask viewers throughout the video to encourage interaction.'
    ),
  callToAction: z
    .string()
    .describe(
      'A clear instruction for viewers to like, subscribe, comment, or visit a link.'
    ),
  conclusion: z.string().describe('Summarizes the video and provides a closing statement.'),
});
export type GenerateVideoScriptOutput = z.infer<
  typeof GenerateVideoScriptOutputSchema
>;

export async function generateVideoScript(
  input: GenerateVideoScriptInput
): Promise<GenerateVideoScriptOutput> {
  return generateVideoScriptFlow(input);
}

const generateVideoScriptPrompt = ai.definePrompt({
  name: 'generateVideoScriptPrompt',
  input: {schema: GenerateVideoScriptInputSchema},
  output: {schema: GenerateVideoScriptOutputSchema},
  prompt: `You are an expert YouTube scriptwriter. Your task is to generate a comprehensive video script based on the provided inputs.

Generate a script that includes a strong hook, a clear introduction, detailed main content, engaging questions for the audience, a compelling call to action, and a concise conclusion.

Video Topic: {{{videoTopic}}}
Target Audience: {{{targetAudience}}}
Script Length: {{{scriptLength}}}
Video Type: {{{videoType}}}

Make sure the script is structured as JSON and adheres to the following schema, including the exact field names:

Output Schema:
hook: An engaging opening statement to grab the viewer's attention.
introduction: Introduces the video topic and what viewers can expect.
mainContent: Key sections or paragraphs covering the main topic. This should be an array of strings, where each string is a paragraph or segment.
engagementQuestions: Questions to ask viewers throughout the video to encourage interaction. This should be an array of strings.
callToAction: A clear instruction for viewers to like, subscribe, comment, or visit a link.
conclusion: Summarizes the video and provides a closing statement.
`,
});

const generateVideoScriptFlow = ai.defineFlow(
  {
    name: 'generateVideoScriptFlow',
    inputSchema: GenerateVideoScriptInputSchema,
    outputSchema: GenerateVideoScriptOutputSchema,
  },
  async (input) => {
    const {output} = await generateVideoScriptPrompt(input);
    return output!;
  }
);
