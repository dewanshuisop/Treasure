'use server';
/**
 * @fileOverview A Genkit flow for generating YouTube thumbnail images and text suggestions.
 *
 * - generateThumbnailImage - A function that handles the generation of thumbnail images and text suggestions.
 * - GenerateThumbnailImageInput - The input type for the generateThumbnailImage function.
 * - GenerateThumbnailImageOutput - The return type for the generateThumbnailImage function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const GenerateThumbnailImageInputSchema = z.object({
  videoTopic: z.string().describe('The topic of the video.'),
  thumbnailStyle: z.string().describe('The desired style for the thumbnail (e.g., minimalist, vibrant, cinematic).'),
  emotion: z.string().describe('The emotion to convey (e.g., exciting, calm, mysterious, humorous).'),
  mainSubject: z.string().describe('The main subject or focal point of the thumbnail.'),
  format: z.enum(['16:9', '9:16']).describe('The aspect ratio for the thumbnail: "16:9" for long form, "9:16" for short form.'),
});
export type GenerateThumbnailImageInput = z.infer<typeof GenerateThumbnailImageInputSchema>;

const GenerateThumbnailImageOutputSchema = z.object({
  thumbnailImage: z
    .string()
    .describe(
      "The generated thumbnail image as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  thumbnailPrompt: z.string().describe('The detailed text prompt used to generate the thumbnail image.'),
  thumbnailTextSuggestions: z.array(z.string()).describe('A list of short text suggestions suitable for overlaying on the thumbnail.'),
});
export type GenerateThumbnailImageOutput = z.infer<typeof GenerateThumbnailImageOutputSchema>;

const thumbnailGeneratorPrompt = ai.definePrompt({
  name: 'thumbnailGeneratorPrompt',
  input: { schema: GenerateThumbnailImageInputSchema },
  output: {
    schema: z.object({
      imageGenerationPrompt: z.string().describe('A detailed, vivid, and concise prompt suitable for a text-to-image AI model to generate a compelling YouTube thumbnail. Be specific about composition, colors, lighting, and elements.'),
      textOverlaySuggestions: z.array(z.string()).describe('An array of 3-5 short, impactful text phrases suitable for overlaying on the thumbnail.'),
    }),
  },
  prompt: `You are an expert YouTube thumbnail designer AI. Your task is to create a compelling image generation prompt and text overlay suggestions for a YouTube video thumbnail based on the user's input.

Video Topic: {{{videoTopic}}}
Thumbnail Style: {{{thumbnailStyle}}}
Emotion to convey: {{{emotion}}}
Main Subject: {{{mainSubject}}}
Aspect Ratio: {{{format}}}

Instructions:
1. Create a detailed, vivid, and concise image generation prompt that incorporates all the provided details. Be specific about composition, colors, lighting, and main elements to make the thumbnail visually striking and relevant. The prompt should be suitable for a text-to-image AI model.
2. Generate 3-5 short, impactful text phrases that could be overlaid on the thumbnail. These should be catchy and relevant to the video topic, designed to grab attention.`,
});

const generateThumbnailImageFlow = ai.defineFlow(
  {
    name: 'generateThumbnailImageFlow',
    inputSchema: GenerateThumbnailImageInputSchema,
    outputSchema: GenerateThumbnailImageOutputSchema,
  },
  async (input) => {
    // Step 1: Generate the image prompt and text suggestions using a text model
    const response = await thumbnailGeneratorPrompt(input);
    
    if (!response.output) {
      throw new Error('The AI was unable to generate a valid prompt for your thumbnail. This might be due to safety filters or a broad topic.');
    }

    const { imageGenerationPrompt, textOverlaySuggestions } = response.output;

    // Step 2: Generate the thumbnail image using the image generation model
    // Note: Config keys like aspectRatio are model-dependent. Using standard string prompt for flexibility.
    const { media } = await ai.generate({
      model: 'googleai/imagen-4.0-fast-generate-001',
      prompt: imageGenerationPrompt,
      config: {
        aspectRatio: input.format === '16:9' ? '16:9' : '9:16',
      },
    });

    if (!media || !media.url) {
      throw new Error('The image generation engine did not return a valid result. Please try a different subject or style.');
    }

    return {
      thumbnailImage: media.url,
      thumbnailPrompt: imageGenerationPrompt,
      thumbnailTextSuggestions: textOverlaySuggestions,
    };
  }
);

export async function generateThumbnailImage(
  input: GenerateThumbnailImageInput
): Promise<GenerateThumbnailImageOutput> {
  return generateThumbnailImageFlow(input);
}
