'use server';
/**
 * @fileOverview A Genkit flow that generates YouTube video ideas based on channel niche, target audience, and content type.
 *
 * - generateVideoIdeas - A function that handles the video idea generation process.
 * - GenerateVideoIdeasInput - The input type for the generateVideoIdeas function.
 * - GenerateVideoIdeasOutput - The return type for the generateVideoIdeas function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const GenerateVideoIdeasInputSchema = z.object({
  channelNiche: z.string().describe("The specific niche or topic of the YouTube channel (e.g., 'tech reviews', 'cooking tutorials', 'travel vlogs')."),
  targetAudience: z.string().describe("The demographic and interests of the target audience (e.g., 'young adults interested in sustainable living', 'gamers who like retro titles')."),
  contentType: z.string().describe("The general type of content usually produced (e.g., 'tutorials', 'vlogs', 'product comparisons', 'storytelling')."),
});
export type GenerateVideoIdeasInput = z.infer<typeof GenerateVideoIdeasInputSchema>;

const VideoIdeaSchema = z.object({
  title: z.string().describe('A captivating title for the video idea.'),
  hook: z.string().describe('A brief, engaging hook to grab viewers\' attention.'),
  thumbnailIdea: z.string().describe('A visual concept for the video thumbnail.'),
  shortDescription: z.string().describe('A short description outlining the video content.'),
  viralScore: z.number().int().min(1).max(10).describe('A score from 1-10 indicating the potential virality of the idea.'),
  difficultyScore: z.number().int().min(1).max(10).describe('A score from 1-10 indicating the estimated difficulty to produce the video.'),
  estimatedViewsPotential: z.string().describe('An estimation of potential views (e.g., "10K-50K", "100K+", "1M+").'),
});

const GenerateVideoIdeasOutputSchema = z.object({
  videoIdeas: z.array(VideoIdeaSchema).min(5).max(10).describe('A list of 5-10 unique YouTube video ideas.'),
});
export type GenerateVideoIdeasOutput = z.infer<typeof GenerateVideoIdeasOutputSchema>;

export async function generateVideoIdeas(input: GenerateVideoIdeasInput): Promise<GenerateVideoIdeasOutput> {
  return generateVideoIdeasFlow(input);
}

const generateVideoIdeasPrompt = ai.definePrompt({
  name: 'generateVideoIdeasPrompt',
  input: { schema: GenerateVideoIdeasInputSchema },
  output: { schema: GenerateVideoIdeasOutputSchema },
  prompt: `You are an expert YouTube content strategist. Your goal is to generate unique and compelling video ideas for a YouTube creator.

Based on the following information, generate 5-7 distinct video ideas. For each idea, provide a:
- Title
- Hook
- Thumbnail Idea
- Short Description
- Viral Score (1-10)
- Difficulty Score (1-10)
- Estimated Views Potential (e.g., "10K-50K", "100K+", "1M+")

Channel Niche: {{{channelNiche}}}
Target Audience: {{{targetAudience}}}
Content Type: {{{contentType}}}

Ensure the ideas are fresh, relevant to the niche and audience, and reflect current trends while also offering potential for good viewership and engagement. The scores should be a realistic assessment for the given niche.`,
});

const generateVideoIdeasFlow = ai.defineFlow(
  {
    name: 'generateVideoIdeasFlow',
    inputSchema: GenerateVideoIdeasInputSchema,
    outputSchema: GenerateVideoIdeasOutputSchema,
  },
  async (input) => {
    const { output } = await generateVideoIdeasPrompt(input);
    if (!output) {
      throw new Error('Failed to generate video ideas.');
    }
    return output;
  }
);
