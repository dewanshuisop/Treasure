import { config } from 'dotenv';
config();

import '@/ai/flows/generate-video-script-flow.ts';
import '@/ai/flows/generate-video-ideas-flow.ts';
import '@/ai/flows/improve-existing-script-flow.ts';
